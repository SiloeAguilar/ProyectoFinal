﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
namespace webapi_csharp.Models
{
    class Ventas
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]

        [Key]
        public int id { get; set; }
        public string articulos { get; set; }
        public string cliente{ get; set; }
        public int total { get; set; }
        public string referencia { get; set; }
        public void mostrarDatos()
        {
            Console.WriteLine("Id: " + id);
            Console.WriteLine("articulos: " + articulos);
            Console.WriteLine("cliente: " + cliente);
            Console.WriteLine("total: " + total);
            Console.WriteLine("referencia: " + referencia);
        
        }
    }


}

