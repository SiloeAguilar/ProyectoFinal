﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
namespace webapi_csharp.Models
{
    class Clientes
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]

        [Key]
        public string nombre { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
        public string email { get; set; }
        public void mostrarDatos()
        {
            Console.WriteLine("Nombre: " + nombre);
            Console.WriteLine("Telefono: " + telefono);
            Console.WriteLine("direccion: " + direccion);
            Console.WriteLine("email: " + email);
        }
    }


}
