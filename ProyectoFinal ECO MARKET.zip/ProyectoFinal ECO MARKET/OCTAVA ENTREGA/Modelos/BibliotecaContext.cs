﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
namespace ProyectoFinal.Models
{
    class BibliotecaContext: DbContext
    {
        public DbSet<Art> Articulos{ get; set; }
        public string connectionString = @"Data Source=SILOE\SQLEXPRESS;Initial Catalog=ECOMARKET;Integrated Security=True";
        protected override void OnConfiguring(DbContextOptionsBuilder options)

          => options.UseSqlServer(connectionString);
    }
}
